//
//  testserver.cpp
//  ModuleSample
//
//  Created by hu_danyuan on 16/12/02.
//  Copyright © 2016年 杭州速凡网络科技有限公司. All rights reserved.
//

#include "testserver.h"
#include <stdio.h>
#include <iostream>

#include "ExtService.h"
#include "Subscribe.h"
#include "SF_ModBridge/BaseModule.h"
#include "SF_ModBridge/ExtServicesManager.h"
#include "SF_ModBridge/SubServicesManager.h"

using namespace sf;
namespace hdy
{
	static ExtService *ext_service = NULL;
	static Subscribe *subscriber = NULL;
	static sf::BaseModule module_info;
}
sf::BaseModule *hdy_load()
{
	hdy::module_info.name = "hdy";
	hdy::module_info.version = "1.0.0";
	hdy::module_info.secret = "04064c009bda2a6ba640d55549642dcb";
	hdy::module_info.init = hdy_init;
	hdy::module_info.deinit = hdy_deinit;
	hdy::module_info.start = hdy_start;
	hdy::module_info.stop = hdy_stop;
	return &hdy::module_info;
}
int hdy_init(unsigned char flag)
{
    std::cout<<"\033[31mhdy_init\033[0m"<<std::endl;
    hdy::subscriber = new hdy::Subscribe();
    hdy::ext_service = new hdy::ExtService();
    return 0;
}
int hdy_start()
{
    std::cout<<"\033[31mhdy_start\033[0m"<<std::endl;
    SubServicesManager::instance()->subscribe(kSubscribeServiceObjectState, hdy::subscriber);
    ExtServicesManager::instance()->registerService("hdy", hdy::ext_service);
    return 0;
}
void hdy_stop()
{
    std::cout<<"\033[31mhdy_stop\033[0m"<<std::endl;
    SubServicesManager::instance()->unsubscribe(hdy::subscriber);
    ExtServicesManager::instance()->unregisterService(hdy::ext_service);
}
void hdy_deinit()
{
    std::cout<<"\033[31mhdy_deinit\033[0m"<<std::endl;
    delete hdy::subscriber;
    hdy::subscriber = NULL;
}
