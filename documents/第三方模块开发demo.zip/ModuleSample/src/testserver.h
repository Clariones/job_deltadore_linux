//
//  testserver.h
//  ModuleSample
//
//  Created by hu_danyuan on 16/12/02.
//  Copyright © 2016年 杭州速凡网络科技有限公司. All rights reserved.
//
//  订阅服务

#ifndef HomeControlCenter_testserver_h
#define HomeControlCenter_testserver_h

namespace sf {
	class BaseModule;
}
#ifdef __cplusplus
extern "C"{
#endif

sf::BaseModule *hdy_load();
int hdy_init(unsigned char flag);
int hdy_start();
void hdy_stop();
void hdy_deinit();

#ifdef __cplusplus
}
#endif

#endif /* HomeControlCenter_testserver_h */
