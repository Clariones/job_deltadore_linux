//
//  ExtService.h
//  ModuleSample
//
//  Created by hu_danyuan on 16/12/02.
//  Copyright © 2016年 杭州速凡网络科技有限公司. All rights reserved.
//
//  订阅服务

#ifndef HomeControlCenter_ExtService_h
#define HomeControlCenter_ExtService_h

#include "SF_ModBridge/IExtService.h"

namespace hdy
{
	class ExtService : public sf::IExtService
	{
	public:
	    /**
	     * 收到请求
	     * @param sender - 请求者名称，以模块名称命名
	     * @param request - 请求内容
	     * @param response - 请求回复内容
	     * @return 200-成功；其它-错误码，参考http错误码
	     */
	    virtual int onRequest(const std::string &sender, const std::string &request, std::string &response);
	};
}

#endif /* HomeControlCenter_ExtService_h */
